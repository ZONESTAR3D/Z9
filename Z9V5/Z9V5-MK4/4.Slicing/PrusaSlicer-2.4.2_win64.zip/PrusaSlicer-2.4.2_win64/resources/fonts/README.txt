NotoSans-Regular.ttf
--------------------
Name: Noto Sans Regular. Version 2.000;GOOG;noto-source:20170915:90ef993387c0; ttfautohint (v1.7) 
It was designed by Monotype Design Team Manufacturer: Monotype Imaging Inc. 
© Copyright 2015 Google Inc. All Rights Reserved.
License: This Font Software is licensed under the SIL Open Font License, Version 1.1. This Font Software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the SIL Open Font License for the specific language, permissions and limitations governing your use of this Font Software.
Supported languages: Afrikaans  Albanian  Azerbaijani  Belarusian  Bosnian  Bulgarian  Catalan  Croatian  Czech  Danish  Dutch  English  Estonian  Finnish  French  German  Greek  Hungarian  Icelandic  Italian  Latvian  Lithuanian  Macedonian  Maltese  Norwegian  Ossetic  Polish  Portugese  Romanian  Russian  Serbian  Slovak  Slovenian  Spanisch  Swedish  Turkish  Ukrainian  Uzbek  Vietnamese  Zulu

NotoSansCJK-Regular.ttc
-----------------------
Noto Sans CJK and Noto Serif CJK comprehensively cover Simplified Chinese, Traditional Chinese, Japanese, and Korean in a unified font family. This includes the full coverage of CJK Ideographs with variation support for 4 regions, Kangxi radicals, Japanese Kana, Korean Hangul, and other CJK symbols and letters in the Basic Multilingual Plane of Unicode. It also provides limited coverage of CJK Ideographs in Plane 2 of Unicode as necessary to support standards from China and Japan.
https://www.google.com/get/noto/help/cjk/
